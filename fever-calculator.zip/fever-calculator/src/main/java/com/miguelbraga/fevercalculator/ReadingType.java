package com.miguelbraga.fevercalculator;

public enum ReadingType {
	
	ORAL, RECTAL, ARMPIT, EAR;

}