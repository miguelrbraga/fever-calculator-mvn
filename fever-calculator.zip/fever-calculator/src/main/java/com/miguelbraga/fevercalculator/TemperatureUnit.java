package com.miguelbraga.fevercalculator;

public enum TemperatureUnit {
	
	CELSIUS, FAHRENHEIT, KELVIN;

}