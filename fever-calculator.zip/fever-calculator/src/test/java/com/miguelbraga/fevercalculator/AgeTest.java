package com.miguelbraga.fevercalculator;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class AgeTest {
	
	private Patient patientA;
	
	@Test
	public void patientAged2With38CelsiusHasFeverRectalReading() {
		patientA = new Patient(2, ReadingType.RECTAL, 38, TemperatureUnit.CELSIUS);
		boolean feverIndicator = patientA.hasFever();
		assertFalse(feverIndicator);		
	}
	
	@Test
	public void patientAged9With38CelsiusHasFeverRectalReading() {
		patientA = new Patient(9, ReadingType.RECTAL, 38, TemperatureUnit.CELSIUS);
		boolean feverIndicator = patientA.hasFever();
		assertFalse(feverIndicator);
	}
	
	@Test
	public void patientAged60With38CelsiusHasFeverRectalReading() {	
		patientA = new Patient(60, ReadingType.RECTAL, 38, TemperatureUnit.CELSIUS);
		boolean feverIndicator = patientA.hasFever();
		assertFalse(feverIndicator);
	}
	
	@Test
	public void patientAged92With38CelsiusHasFeverRectalReading() {
		patientA = new Patient(92, ReadingType.RECTAL, 38, TemperatureUnit.CELSIUS);
		boolean feverIndicator = patientA.hasFever();
		assertTrue(feverIndicator);
	}

}
