package com.miguelbraga.fevercalculator;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import org.junit.Test;

public class TemperatureTest {
	
	private Patient patientA;
	
	@Test
	public void patientWith42CelciusHasFever() {
		patientA = new Patient(25, ReadingType.ARMPIT, 42, TemperatureUnit.CELSIUS);
		boolean feverIndicator = patientA.hasFever();
		assertTrue(feverIndicator);	
	}
	
	@Test
	public void patientWith36CelciusDoesNotHaveFever() {
		patientA = new Patient(25, ReadingType.ARMPIT, 36, TemperatureUnit.CELSIUS);
		boolean feverIndicator = patientA.hasFever();
		assertFalse(feverIndicator);	
	}
	
	@Test
	public void patientWith108FahrenheitHasFever() {
		patientA = new Patient(25, ReadingType.ARMPIT, 108, TemperatureUnit.FAHRENHEIT);
		boolean feverIndicator = patientA.hasFever();
		assertTrue(feverIndicator);	
	}
	
	@Test
	public void patientWith97FahrenheitDoesNotHaveFever() {
		patientA = new Patient(25, ReadingType.ARMPIT, 97, TemperatureUnit.FAHRENHEIT);
		boolean feverIndicator = patientA.hasFever();
		assertFalse(feverIndicator);
	}
	
	@Test
	public void patientWith315KelvinHasFever() {
		patientA = new Patient(25, ReadingType.ARMPIT, 315, TemperatureUnit.KELVIN);
		boolean feverIndicator = patientA.hasFever();
		assertTrue(feverIndicator);	
	}
	
	@Test
	public void patientWith309KelvinDoesNotHaveFever() {
		patientA = new Patient(25, ReadingType.ARMPIT, 309
				, TemperatureUnit.KELVIN);
		boolean feverIndicator = patientA.hasFever();
		assertFalse(feverIndicator);	
	}

}
