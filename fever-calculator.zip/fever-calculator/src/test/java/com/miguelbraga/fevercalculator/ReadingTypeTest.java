package com.miguelbraga.fevercalculator;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class ReadingTypeTest {
	
	private Patient patientA;
	
	@Test
	public void patientAged25With37CelsiusHasFeverArmpitReading() {
		patientA = new Patient(25, ReadingType.ARMPIT, 37, TemperatureUnit.CELSIUS);
		boolean feverIndicator = patientA.hasFever();
		assertTrue(feverIndicator);		
	}
	
	@Test
	public void patientAged25With37CelsiusHasFeverEarReading() {
		patientA = new Patient(25, ReadingType.EAR, 37, TemperatureUnit.CELSIUS);
		boolean feverIndicator = patientA.hasFever();
		assertFalse(feverIndicator);		
	}
	
	@Test
	public void patientAged25With37CelsiusHasFeverOralReading() {
		patientA = new Patient(25, ReadingType.ORAL, 37, TemperatureUnit.CELSIUS);
		boolean feverIndicator = patientA.hasFever();
		assertFalse(feverIndicator);		
	}
	
	@Test
	public void patientAged25With37CelsiusHasFeverRectalReading() {
		patientA = new Patient(25, ReadingType.RECTAL, 37, TemperatureUnit.CELSIUS);
		boolean feverIndicator = patientA.hasFever();
		assertFalse(feverIndicator);		
	}

}
